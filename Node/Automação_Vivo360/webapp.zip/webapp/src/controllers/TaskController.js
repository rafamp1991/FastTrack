import Task from '../models/Task';

export default {
  async index(req, res) {
    const tasks = [];
    return res.status(200).json(tasks);
  }
}