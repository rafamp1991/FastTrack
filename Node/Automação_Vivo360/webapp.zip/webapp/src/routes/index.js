import tasksRoute from './tasks';

export default [
  tasksRoute
];