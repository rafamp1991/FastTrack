import Sequelize from 'sequelize';
import db from '../database/connection';

const Task = db.define('tasks', {
  id: {
    type: Sequelize.BIGINT,
    autoIncrement: true,
    primaryKey: true
  },
  system: {
    type: Sequelize.ENUM,
    values: ['Vivo360']
  }
});

export default Task;