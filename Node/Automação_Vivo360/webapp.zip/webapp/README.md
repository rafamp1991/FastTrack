# PoC - Criação de usuários automaticamente

Criar uma migração:

```bash
    $ yarn sequelize-cli migration:create --name NOME_DA_MIGRACAO
```

Executar as migrações:

```bash
    $ yarn sequelize-cli db:migrate
```